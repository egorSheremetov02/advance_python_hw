from fib import fib

if __name__ == '__main__':
    n = int(input())
    print(fib(n))
